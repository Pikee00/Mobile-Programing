package com.example.implicitintentapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etWebsite = findViewById<EditText>(R.id.etWebsite)
        val btnOpenWebsite = findViewById<Button>(R.id.btnOpenWebsite)

        val etLocation = findViewById<EditText>(R.id.etLocation)
        val btnOpenLocation = findViewById<Button>(R.id.btnOpenLocation)

        // Intent untuk membuka website
        btnOpenWebsite.setOnClickListener {
            val url = etWebsite.text.toString()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }

        // Intent untuk membuka lokasi di Maps
        btnOpenLocation.setOnClickListener {
            val location = etLocation.text.toString()
            val geoUri = Uri.parse("geo:0,0?q=$location")
            val intent = Intent(Intent.ACTION_VIEW, geoUri)
            intent.setPackage("com.google.android.apps.maps") // Pakai Google Maps
            startActivity(intent)
        }
    }
}