import 'package:flutter/material.dart';

class TabViewPage extends StatelessWidget {
  const TabViewPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3, // jumlah tab
      child: Scaffold(
        appBar: AppBar(
          title: Text("Contoh TabView dengan UI yang Lebih Menarik"),
          backgroundColor: Colors.teal, // Mengubah warna background appBar
          bottom: TabBar(
            indicatorColor: Colors.orange, // Mengubah warna indikator tab
            labelColor: Colors.white, // Warna teks tab yang aktif
            unselectedLabelColor: Colors.grey, // Warna teks tab yang tidak aktif
            tabs: [
              Tab(icon: Icon(Icons.home), text: "Tab 1"),
              Tab(icon: Icon(Icons.search), text: "Tab 2"),
              Tab(icon: Icon(Icons.notifications), text: "Tab 3"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            Center(child: Text("Isi dari Tab 1", style: TextStyle(fontSize: 24, color: Colors.blue))),
            Center(child: Text("Isi dari Tab 2", style: TextStyle(fontSize: 24, color: Colors.green))),
            Center(child: Text("Isi dari Tab 3", style: TextStyle(fontSize: 24, color: Colors.red))),
          ],
        ),
      ),
    );
  }
}
