import 'package:flutter/material.dart';
import 'package:flutter_application_1/page/googleMaps_page.dart';
import 'package:flutter_application_1/page/list_page.dart';
import 'package:flutter_application_1/page/checkbox_page.dart';
import 'package:flutter_application_1/page/profile_page.dart';
import 'package:flutter_application_1/page/welcome_page.dart';
import 'package:flutter_application_1/page/autocomplete.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> { 
  int currentPage = 1;

  // Tambahkan ini!2flutter 
  final List<Widget> _pages = [
    ProfilePage(),
    WelcomePage(), 
    ListPage(), 
    CheckboxPage(), AutocompletePage(), GoogleMapsPage() ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Scaffold(
        body: _pages[currentPage],
        bottomNavigationBar: SalomonBottomBar(
          currentIndex: currentPage,
          onTap: (i) => setState(() => currentPage = i),
          items: [

           
          ],
        ),
      ),
    );
  }
}