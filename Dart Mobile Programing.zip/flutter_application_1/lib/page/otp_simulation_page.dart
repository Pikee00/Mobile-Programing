import 'package:flutter/material.dart';
import 'package:flutter_application_1/page/main_page.dart';

class OtpSimulationPage extends StatefulWidget {
  const OtpSimulationPage({super.key});

  @override
  State<OtpSimulationPage> createState() => _OtpSimulationPageState();
}

class _OtpSimulationPageState extends State<OtpSimulationPage> {
  String _otpCode = '';
  final TextEditingController _controller = TextEditingController();

  void _verifyOtp() {
    if (_otpCode == "123456") {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MainPage()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("❌ OTP Salah")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Simulasi OTP")),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Masukkan Kode OTP (contoh: 123456)",
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _controller,
              maxLength: 6,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Kode OTP",
              ),
              onChanged: (value) {
                setState(() {
                  _otpCode = value;
                });
              },
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _verifyOtp,
              child: const Text("Verifikasi"),
            ),
          ],
        ),
      ),
    );
  }
}
