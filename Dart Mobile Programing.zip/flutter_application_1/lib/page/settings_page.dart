import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TextEditingController _nameController = TextEditingController();
  bool isDarkMode = false;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    _nameController.text = prefs.getString('username') ?? '';
    isDarkMode = prefs.getBool('darkmode') ?? false;
    setState(() {});
  }

  Future<void> _savePreferences() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('username', _nameController.text);
    await prefs.setBool('darkmode', isDarkMode);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Pengaturan berhasil disimpan')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pengaturan')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Nama Pengguna'),
            ),
            SwitchListTile(
              title: Text('Mode Gelap'),
              value: isDarkMode,
              onChanged: (val) {
                setState(() => isDarkMode = val);
              },
            ),
            ElevatedButton(
              onPressed: _savePreferences,
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}
