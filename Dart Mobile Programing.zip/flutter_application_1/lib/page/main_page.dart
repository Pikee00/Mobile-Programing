import 'package:flutter/material.dart';
import 'package:flutter_application_1/page/googleMaps_page.dart';
import 'package:flutter_application_1/page/list_page.dart';
import 'package:flutter_application_1/page/checkbox_page.dart';
import 'package:flutter_application_1/page/profile_page.dart';
import 'package:flutter_application_1/page/welcome_page.dart';
import 'package:flutter_application_1/page/autocomplete.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';


class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> { 
  int currentPage = 0;

  // Tambahkan ini!2flutter 
  final List<Widget> _pages = [
    ProfilePage(), 
    ListPage(), 
    CheckboxPage(), AutocompletePage(), GoogleMapsPage() ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Scaffold(
        body: _pages[currentPage],
        bottomNavigationBar: SalomonBottomBar(
          currentIndex: currentPage,
          onTap: (i) => setState(() => currentPage = i),
          items: [

            SalomonBottomBarItem(
              icon: Icon(Icons.person),
              title: Text("Profile"),
              selectedColor: Colors.blue,
            ),
            SalomonBottomBarItem(
              icon: Icon(Icons.list),
              title: Text("List"),
              selectedColor: Colors.blue,
            ),
            SalomonBottomBarItem(
              icon: Icon(Icons.check_box),
              title: Text("CheckBox"),
              selectedColor: Colors.blue,
            ),
             SalomonBottomBarItem(
              icon: Icon(Icons.search),
              title: Text("Search"),
              selectedColor: Colors.blue,
            ),
            SalomonBottomBarItem(
              icon: Icon(Icons.location_pin),
              title: Text("Maps"),
              selectedColor: Colors.blue,
            ),
          ],
        ),
      ),
    );
  }
}