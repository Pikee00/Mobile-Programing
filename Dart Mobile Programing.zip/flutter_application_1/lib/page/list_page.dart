import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/pertemuan.dart';
import 'package:flutter_application_1/services/data_service.dart';
import 'pertemuan_page.dart';

class ListPage extends StatefulWidget {
  const ListPage({super.key});

  @override
  State<ListPage> createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  late Future<List<Pertemuan>> _futurePertemuan;

  @override
  void initState() {
    super.initState();
    _futurePertemuan = fetchPertemuan(); // Ambil data async
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daftar Pertemuan"),
        backgroundColor: Colors.blueAccent,
      ),
      body: FutureBuilder<List<Pertemuan>>(
        future: _futurePertemuan,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else {
            final data = snapshot.data ?? [];
            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 3,
                  margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  child: ListTile(
                    title: Text(data[index].title),
                    subtitle: Text(data[index].subtitle),
                    leading: CircleAvatar(
                      child: Text(data[index].title.split(" ").last),
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              PertemuanPage(pertemuan: data[index]),
                        ),
                      );
                    },
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
