import 'package:flutter/material.dart';
import 'package:sms_autofill/sms_autofill.dart';

class SmsOtpPage extends StatefulWidget {
  const SmsOtpPage({Key? key}) : super(key: key);

  @override
  State<SmsOtpPage> createState() => _SmsOtpPageState();
}

class _SmsOtpPageState extends State<SmsOtpPage> with CodeAutoFill {
  String? _otpCode;

  @override
  void initState() {
    super.initState();
    _listenOtpCode();
  }

  void _listenOtpCode() async {
    await SmsAutoFill().unregisterListener();
    listenForCode();
    String signature = await SmsAutoFill().getAppSignature;
    debugPrint("App Signature: $signature");
  }

  // Ini tidak perlu pakai @override
  void codeUpdated(String code) {
    setState(() {
      _otpCode = code;
    });
  }

  @override
  void dispose() {
    cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("OTP SMS Autofill")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Masukkan OTP yang dikirim ke nomor kamu"),
            const SizedBox(height: 20),
            PinFieldAutoFill(
              codeLength: 6,
              onCodeChanged: (code) {
                if (code != null && code.length == 6) {
                  FocusScope.of(context).unfocus();
                  setState(() {
                    _otpCode = code;
                  });
                }
              },
            ),
            const SizedBox(height: 20),
            Text("Kode diterima: $_otpCode"),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Kode OTP: $_otpCode")),
                );
              },
              child: const Text("Verifikasi"),
            ),
          ],
        ),
      ),
    );
  }
}
