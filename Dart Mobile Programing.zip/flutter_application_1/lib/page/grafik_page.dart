import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'dart:math';

class GrafikPage extends StatelessWidget {
  const GrafikPage({super.key});

  @override
  Widget build(BuildContext context) {
    final random = Random();
    final List<FlSpot> dataPoints = List.generate(
      30,
      (index) => FlSpot(index.toDouble(), 100 + random.nextInt(100).toDouble()),
    );

    // Tentukan warna per segmen (naik = hijau, turun = merah)
    final List<LineChartBarData> segments = [];
    for (int i = 0; i < dataPoints.length - 1; i++) {
      final current = dataPoints[i];
      final next = dataPoints[i + 1];
      final isNaik = next.y >= current.y;

      segments.add(LineChartBarData(
        spots: [current, next],
        isCurved: false,
        color: isNaik ? Colors.greenAccent : Colors.redAccent,
        barWidth: 3,
        dotData: FlDotData(show: false),
      ));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Grafik Kejayaan Kekaisaran'),
        backgroundColor: Colors.black,
      ),
      body: Container(
        color: Colors.black,
        padding: const EdgeInsets.all(16),
        child: LineChart(
          LineChartData(
            lineBarsData: segments,
            titlesData: FlTitlesData(
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 5,
                  getTitlesWidget: (value, _) => Text(
                    'Hari ${value.toInt()}',
                    style: const TextStyle(color: Colors.white70, fontSize: 10),
                  ),
                ),
              ),
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 20,
                  getTitlesWidget: (value, _) => Text(
                    value.toInt().toString(),
                    style: const TextStyle(color: Colors.white70, fontSize: 10),
                  ),
                ),
              ),
              rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            gridData: FlGridData(
              show: true,
              drawHorizontalLine: true,
              drawVerticalLine: true,
              getDrawingHorizontalLine: (_) => FlLine(color: Colors.white10, strokeWidth: 1),
              getDrawingVerticalLine: (_) => FlLine(color: Colors.white10, strokeWidth: 1),
            ),
            borderData: FlBorderData(
              show: true,
              border: const Border(
                bottom: BorderSide(color: Colors.white),
                left: BorderSide(color: Colors.white),
              ),
            ),
            minY: 80,
            maxY: 200,
          ),
        ),
      ),
    );
  }
}
