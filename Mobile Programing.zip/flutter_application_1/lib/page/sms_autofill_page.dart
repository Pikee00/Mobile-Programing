import 'package:flutter/material.dart';
import 'package:sms_autofill/sms_autofill.dart';

class SmsAutofillPage extends StatefulWidget {
  const SmsAutofillPage({super.key});

  @override
  State<SmsAutofillPage> createState() => _SmsAutofillPageState();
}

class _SmsAutofillPageState extends State<SmsAutofillPage> with CodeAutoFill {
  String? _otpCode;

  @override
  void initState() {
    super.initState();
    listenForCode(); // mulai mendengarkan SMS
  }

  @override
  void codeUpdated(String code) {
    setState(() {
      _otpCode = code;
    });
  }

  @override
  void dispose() {
    cancel(); // berhenti mendengarkan ketika halaman keluar
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("SMS Autofill (OTP)")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Masukkan Kode OTP",
              style: TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 20),
            PinFieldAutoFill(
              codeLength: 6,
              onCodeChanged: (code) {
                setState(() {
                  _otpCode = code;
                });
              },
            ),
            const SizedBox(height: 20),
            Text("Kode diterima: $_otpCode"),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Kode: $_otpCode")),
                );
              },
              child: const Text("Kirim OTP"),
            ),
          ],
        ),
      ),
    );
  }
}
