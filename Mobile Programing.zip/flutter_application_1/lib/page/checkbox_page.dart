import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class CheckboxPage extends StatefulWidget {
  const CheckboxPage({super.key});

  @override
  State<CheckboxPage> createState() => _CheckboxPageState();
}

class _CheckboxPageState extends State<CheckboxPage> {
  Map<String, bool> typeSelections = {
    'Assasin': false,
    'Knight': false,
    'Mage': false,
    'Archer': false,
    'Priest': false,
  };

  Map<String, bool> levelSelections = {
    'Bronze': false,
    'Silver': false,
    'Gold': false,
    'Diamond': false,
    'Mystic': false,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple.shade100,
      appBar: AppBar(
        backgroundColor: Colors.brown.shade700,
        title: const Text(
          'Dragon Kingdom',
          style: TextStyle(
            fontFamily: 'MedievalSharp',
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 24),
          child: Column(
            children: [
              menuExpansion('TYPE', Icons.shield, typeSelections),
              const SizedBox(height: 16),
              menuExpansion('LEVEL', Icons.military_tech, levelSelections),
              const SizedBox(height: 32),
              const Text(
                'Menu yang dipilih',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'MedievalSharp',
                ),
              ),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.brown, width: 2),
                  ),
                  child: Text(
                    getSelectedMenu(),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton.icon(
                onPressed: () => showMyAlert(context),
                icon: const Icon(Icons.info_outline),
                label: const Text('Detail'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepOrange,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  textStyle: const TextStyle(fontSize: 16),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: showMyToast,
                icon: const Icon(Icons.exit_to_app),
                label: const Text('Keluar'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  textStyle: const TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget menuExpansion(String title, IconData icon, Map<String, bool> selections) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.amber.shade100,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.brown.shade600, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 6,
            offset: const Offset(2, 4),
          ),
        ],
      ),
      child: ExpansionTile(
        leading: Icon(icon, color: Colors.brown.shade700),
        title: Text(
          title,
          style: const TextStyle(
            fontFamily: 'MedievalSharp',
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        children: selections.keys.map((key) {
          return CheckboxListTile(
            title: Text(key),
            value: selections[key],
            activeColor: Colors.deepPurple,
            onChanged: (value) {
              setState(() {
                selections[key] = value!;
              });
            },
          );
        }).toList(),
      ),
    );
  }

  String getSelectedMenu() {
    List<String> selectedMenu = [];

    selectedMenu.addAll(typeSelections.entries
        .where((entry) => entry.value)
        .map((entry) => entry.key));

    selectedMenu.addAll(levelSelections.entries
        .where((entry) => entry.value)
        .map((entry) => entry.key));

    if (selectedMenu.isEmpty) return 'Tidak ada yang dipilih';

    return selectedMenu.join(', ');
  }

  void showMyAlert(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Informasi'),
          content: Text('Menu yang dipilih:\n${getSelectedMenu()}'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Tutup'),
            ),
          ],
        );
      },
    );
  }

  void showMyToast() {
    Fluttertoast.showToast(
      msg: "Terima kasih telah memilih menu!",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.black54,
      textColor: Colors.white,
      fontSize: 14.0,
    );
  }
}
