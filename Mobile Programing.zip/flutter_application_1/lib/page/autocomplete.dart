import 'package:flutter/material.dart';
import 'package:flutter_application_1/page/profile_page.dart';
import 'package:flutter_application_1/page/camera_page.dart';
import 'package:flutter_application_1/page/grafik_page.dart';
import 'package:flutter_application_1/page/checkbox_page.dart';

enum ButtonState { init, loading, done }

class AutocompletePage extends StatefulWidget {
  const AutocompletePage({super.key});

  @override
  State<AutocompletePage> createState() => _AutocompletePageState();
}

class _AutocompletePageState extends State<AutocompletePage> {
  bool isAnimating = true;
  ButtonState state = ButtonState.init;
  final TextEditingController _controller = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isDone = state == ButtonState.done;
    final isStretched = isAnimating || state == ButtonState.init;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Kaisar Navigator"),
        backgroundColor: Colors.red.shade400,
        actions: [
          IconButton(
            onPressed: () {
              showSearch(context: context, delegate: MySearch(context));
            },
            icon: const Icon(Icons.search),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const Text(
                "Masukkan Nama Kaisar",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _controller,
                decoration: const InputDecoration(
                  hintText: "Contoh: Kaisar Nero",
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value == null || value.isEmpty ? "Nama tidak boleh kosong!" : null,
              ),
              const SizedBox(height: 40),
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeIn,
                width: state == ButtonState.init ? width * 0.6 : 60,
                onEnd: () => setState(() => isAnimating = !isAnimating),
                height: 70,
                child: isStretched ? buildButton() : buildSmallButton(isDone),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildButton() => OutlinedButton(
        style: TextButton.styleFrom(
          shape: const StadiumBorder(),
          padding: const EdgeInsets.symmetric(horizontal: 32),
        ),
        onPressed: () async {
          if (!_formKey.currentState!.validate()) return;

          setState(() => state = ButtonState.loading);
          await Future.delayed(const Duration(seconds: 2));

          String nama = _controller.text;
          debugPrint("Nama Kaisar: $nama");

          if (!mounted) return;
          setState(() => state = ButtonState.done);

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Data '$nama' berhasil disimpan.")),
          );

          await Future.delayed(const Duration(seconds: 2));
          if (!mounted) return;
          setState(() => state = ButtonState.init);
        },
        child: const Text(
          'Submit',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.deepPurple,
          ),
        ),
      );

  Widget buildSmallButton(bool isDone) {
    final color = isDone ? Colors.green : Colors.indigo;
    return Container(
      decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      child: Center(
        child: isDone
            ? const Icon(Icons.done, size: 52, color: Colors.white)
            : const CircularProgressIndicator(color: Colors.white),
      ),
    );
  }
}

// === SEARCH DELEGATE ===
class MySearch extends SearchDelegate {
  final BuildContext context;
  MySearch(this.context);

  final List<String> searchResults = [
    'Profil',
    'Ambil Foto',
    'Grafik Data',
    'Checkbox',
  ];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => close(context, null),
      );

  @override
  List<Widget>? buildActions(BuildContext context) => [
        IconButton(
          onPressed: () {
            if (query.isEmpty) {
              close(context, null);
            } else {
              query = '';
            }
          },
          icon: const Icon(Icons.clear),
        ),
      ];

  @override
  Widget buildResults(BuildContext context) {
    switch (query.toLowerCase()) {
      case 'profil':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilePage()));
        break;
      case 'ambil foto':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const CameraPage()));
        break;
      case 'grafik data':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const GrafikPage()));
        break;
      case 'checkbox':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const CheckboxPage()));
        break;
      default:
        return AlertDialog(
          title: const Text("Fitur Tidak Dikenal"),
          content: Text("Fitur '$query' belum tersedia."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Tutup"),
            ),
          ],
        );
    }
    return const SizedBox(); // Aman walau tidak return widget aktif
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    final List<String> suggestions = searchResults
        .where((searchResult) => searchResult.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return ListView.builder(
      itemCount: suggestions.length,
      itemBuilder: (context, index) {
        final suggestion = suggestions[index];
        return ListTile(
          title: Text(suggestion),
          leading: const Icon(Icons.featured_play_list),
          onTap: () {
            query = suggestion;
            showResults(context);
          },
        );
      },
    );
  }
}
