import 'package:flutter/material.dart';
import 'package:flutter_application_1/page/welcome_page.dart';
import 'package:flutter_application_1/services/preferences_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_application_1/page/settings_page.dart';
import 'package:flutter_application_1/page/grafik_page.dart';
import 'package:flutter_application_1/page/camera_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String username = "MUHAMAD TAUFIK DZULFIKRI";
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadUsername();
  }

  void _loadUsername() async {
    final name = await PreferencesService.getUsername();
    setState(() {
      username = name ?? "MUHAMAD TAUFIK DZULFIKRI";
      _controller.text = username;
    });
  }

  void _saveUsername() async {
    await PreferencesService.saveUsername(_controller.text);
    _loadUsername();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Nama berhasil disimpan!")),
    );
  }

  void _clearPrefs() async {
    await PreferencesService.clear();
    _loadUsername();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Data direset!")),
    );
  }

  void _logout() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const WelcomePage()),
    );
  }

  void _logoutAndClear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    _logout();
  }

  void _openGrafik() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const GrafikPage()),
    );
  }

  void _openCamera() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const CameraPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'Menu Utama',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Buka Kamera'),
              onTap: () {
                Navigator.pop(context);
                _openCamera();
              },
            ),
            ListTile(
              leading: const Icon(Icons.bar_chart),
              title: const Text('Grafik'),
              onTap: () {
                Navigator.pop(context);
                _openGrafik();
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Pengaturan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const SettingsPage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Keluar Aplikasi'),
              onTap: _logoutAndClear,
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: const Text("Profile Kaisar"),
        backgroundColor: Colors.black.withOpacity(0.5),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'save') {
                _saveUsername();
              } else if (value == 'clear') {
                _clearPrefs();
              } else if (value == 'logout') {
                _logout();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'save', child: Text('Simpan Nama')),
              const PopupMenuItem(value: 'clear', child: Text('Reset')),
              const PopupMenuItem(value: 'logout', child: Text('Logout')),
            ],
          ),
        ],
      ),
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          Image.network(
            'https://i.imgur.com/Nn2lXnZ.jpeg',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  const SizedBox(height: 150),
                  const CircleAvatar(
                    backgroundImage: NetworkImage(
                      'https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/esensi/2023/12/joseph-stalin-gettyimages-464426375.jpg',
                    ),
                    radius: 60.0,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    username.toUpperCase(),
                    style: const TextStyle(
                      fontSize: 25,
                      color: Colors.white,
                      letterSpacing: 2.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Moskow, Rusia",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Russian Emperor",
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _controller,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: "Ganti Nama",
                      labelStyle: const TextStyle(color: Colors.white),
                      enabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: 15),

                  // Baris Tombol Simpan - Kamera - Grafik
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      ElevatedButton(
                        onPressed: _saveUsername,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.9),
                          foregroundColor: Colors.black,
                        ),
                        child: const Text("Simpan Nama"),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton.icon(
                        onPressed: _openCamera,
                        icon: const Icon(Icons.camera_alt),
                        label: const Text("Kamera"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.9),
                          foregroundColor: Colors.black,
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton.icon(
                        onPressed: _openGrafik,
                        icon: const Icon(Icons.bar_chart),
                        label: const Text("Grafik"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.9),
                          foregroundColor: Colors.black,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),
                  Card(
                    color: Colors.white.withOpacity(0.8),
                    margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 8),
                    child: const Padding(
                      padding: EdgeInsets.all(8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  "Post",
                                  style: TextStyle(
                                    color: Colors.blueAccent,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                SizedBox(height: 7),
                                Text(
                                  "10",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w300,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  "Followers",
                                  style: TextStyle(
                                    color: Colors.blueAccent,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                SizedBox(height: 7),
                                Text(
                                  "2 juta",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w300,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 50),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
