import 'package:flutter/foundation.dart';

int heavyCalculation(int value) {
  int result = 0;
  for (int i = 0; i < 100000000; i++) {
    result += value;
  }
  return result;
}
