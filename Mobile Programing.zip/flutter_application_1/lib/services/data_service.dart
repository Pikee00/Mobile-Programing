import 'package:flutter_application_1/models/pertemuan.dart';

Future<List<Pertemuan>> fetchPertemuan() async {
  await Future.delayed(Duration(seconds: 2)); // Simulasi loading dari server
  return [
    Pertemuan(title: 'Pertemuan 1', subtitle: 'Pengenalan Android'),
    Pertemuan(title: 'Pertemuan 2', subtitle: 'Widget & Button'),
    Pertemuan(title: 'Pertemuan 3', subtitle: 'Activity & Intent'),
    Pertemuan(title: 'Pertemuan 4', subtitle: 'Toast & AlertDialog'),
    Pertemuan(title: 'Pertemuan 5', subtitle: 'ListView'),
    Pertemuan(title: 'Pertemuan 6', subtitle: 'Checkbox'),
    Pertemuan(title: 'Pertemuan 7', subtitle: 'Radio Button'),
    Pertemuan(title: 'Pertemuan 8', subtitle: 'Autocomplete'),
  ];
}
